import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  constructor() { }
  modal = false;
  showModalq = false;
  ngOnInit(): void {
  }
  alert(){
    window.alert("helllo");
  }
  showModal(){
    console.log("insode")
    this.modal = true;
  }
}
